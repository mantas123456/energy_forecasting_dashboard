import pandas as pd
import numpy as np
from prophet import Prophet

print("✅ All core packages imported successfully.")
print("🧪 Pandas version:", pd.__version__)
print("🧪 NumPy version:", np.__version__)
